(function(news){

    var apikey = '16dc9947506c7c2f8b2a38bcd93e0740';
    //import CryptoNewsApi from 'crypto-news-api'
    // For ES5, use the below import instead
    var CryptoNewsAPI = require('crypto-news-api')["default"];
    // Connect to the CryptoControl API
    var Api = new CryptoNewsAPI(apikey);
    // Connect to a self-hosted proxy server (to improve performance) that points to cryptocontrol.io
    //const ProxyApi = new CryptoNewsAPI('API_KEY_HERE', 'http://cryptocontrol_proxy/api/v1/public')
    // Enable the sentiment datapoints
    Api.enableSentiment();
    // Get top news
    
    news.getTopNews = ()=> {return Api.getTopNews();}
    news.getTopNewsByCoin = (coin)=> {return Api.getTopNewsByCoin(coin);}
    news.getLatestTweetsByCoin = (coin)=> {return Api.getLatestTweetsByCoin(coin);}
    news.getLatestRedditPostsByCoin = (coin)=> {return Api.getLatestRedditPostsByCoin(coin);}
    news.getTopFeedByCoin = (coin)=> {return Api.getTopFeedByCoin(coin);}
    news.getTopItemsByCoin = (coin)=> {return Api.getTopItemsByCoin(coin);}
    news.getCoinDetails = (coin)=> {return Api.getTopNews(coin);}
    })(module.exports)
    
    // Api.getTopNews()
    //     .then(function (articles) { console.log(articles); })["catch"](function (error) { console.log(error); });
    // // Get latest russian news
    // Api.getTopNews("ru")
    //     .then(function (articles) { console.log(articles); })["catch"](function (error) { console.log(error); });
    // // Get top news for Bitcoin
    // Api.getTopNewsByCoin("bitcoin")
    //     .then(function (articles) { console.log(articles); })["catch"](function (error) { console.log(error); });
    // // Get latest tweets for EOS
    // Api.getLatestTweetsByCoin("eos")
    //     .then(function (tweets) { console.log(tweets); })["catch"](function (error) { console.log(error); });
    // // Get latest reddit posts for Ripple
    // Api.getLatestRedditPostsByCoin("ripple")
    //     .then(function (redditPosts) { console.log(redditPosts); })["catch"](function (error) { console.log(error); });
    // // Get a combined feed (reddit/twitter/articles) for Litecoin
    // Api.getTopFeedByCoin("litecoin")
    //     .then(function (feed) { console.log(feed); })["catch"](function (error) { console.log(error); });
    // // Get all reddit/tweets/articles (separated) for NEO
    // Api.getTopItemsByCoin("neo")
    //     .then(function (feed) { console.log(feed); })["catch"](function (error) { console.log(error); });
    // // Get coin details for ethereum
    // Api.getCoinDetails("ethereum")
    //     .then(function (details) { console.log(details); })["catch"](function (error) { console.log(error); });
    
    