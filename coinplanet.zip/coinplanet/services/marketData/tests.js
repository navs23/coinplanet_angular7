var Factory = new require('./factory');
var mdfactory = new Factory('cmc');
console.log(mdfactory);
var marketDataService = mdfactory.getMarketDataServiceByProider();

console.log(marketDataService);
var promise = marketDataService.getPrice(true);
promise.then(response => {
     
    console.log(response);
  });
  promise.catch((err) => {
   
    console.log(err);
  });

  class test{}