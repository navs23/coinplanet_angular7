var factory = require('./factory');
(function(md){  

     var service = factory.getMarketDataServiceByProider('cmp');
     
     md.service = service;

    }(module.exports))
