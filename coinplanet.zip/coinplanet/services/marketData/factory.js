 class Factory {
     
     constructor(provider){
        console.log('value passed - ' + provider);
         this.setting =provider || 'cmc';
         console.log('setting - ' + this.setting);
         
     }

     getMarketDataServiceByProider(){
        console.log('setting - ' + this.setting);
      
        if (this.setting ==='cmc')
        var marketDataProvider = require('./coinmarketcap');    
        return marketDataProvider; 
    }
    
}

module.exports =Factory;