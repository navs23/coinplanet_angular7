(function(cmcService){
    
    cmcService.getPrice=(fromCache)=>{
        if (fromCache)
        return getLatestPriceFromCache();
        return getLatestPrice();    
    }
   

}(module.exports))


getLatestPrice=()=>{

    const requestOptions = {
        method: 'GET',
        uri: 'https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest',
        qs: {
          start: 1,
          limit: 5000,
          convert: 'USD'
        },
        headers: {
          'X-CMC_PRO_API_KEY': req.app.get('cmcapikey')
        },
        json: true,
        gzip: true
      };
      return rp(requestOptions);
     
       
}
getLatestPriceFromCache=()=>{
    console.log('from cache');
    const fs= require('fs');
    return new Promise((resolve,reject)=>{
        try {
            var json = JSON.parse(fs.readFileSync('./services/data/price.json', 'utf8'));                   
             resolve(json);
        } catch (error) {
             reject(error);
        }
                   
    });
}
