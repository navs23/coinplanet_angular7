var factory = require('./factory');
(function(md){  

     var service = factory.getFiatService('fixer');
     
     md.service = service;

    }(module.exports))
