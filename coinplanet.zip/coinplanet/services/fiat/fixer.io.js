(function(cmcService){
    
    cmcService.getRates=(fromCache)=>{
        if (fromCache)
        return getRatesFromCache();
        return getRates();
    

    }
   

}(module.exports))


getRates=()=>{

    const requestOptions = {
        method: 'GET',
        uri: 'https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest',
        qs: {
          start: 1,
          limit: 5000,
          convert: 'USD'
        },
        headers: {
          'X-CMC_PRO_API_KEY': req.app.get('cmcapikey')
        },
        json: true,
        gzip: true
      };
      return rp(requestOptions);
     
       
}
getRatesFromCache=()=>{
    console.log('from cache');
    const fs= require('fs');
    return new Promise((resolve,reject)=>{
        try {
            var json = JSON.parse(fs.readFileSync('./services/data/fiat.json', 'utf8'));                   
             resolve(json);
        } catch (error) {
             reject(error);
        }
                   
    });
}
