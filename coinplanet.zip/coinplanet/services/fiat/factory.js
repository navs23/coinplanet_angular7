 class Factory {
     
     constructor(provider){
        
         this.setting =provider || 'fixer';
         
         
     }

     getFiatService(){
        if (this.setting ==='fixer')
        var fiatDataProvider = require('./fixer.io');    
        return fiatDataProvider; 
    }
    
}

module.exports =Factory;