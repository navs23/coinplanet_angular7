var RatesFactory = new require('./factory');
var fixer = new RatesFactory('fixer');

var ds = fixer.getFiatService();
var promise = ds.getRates(true);

promise.then(response => {
  
    console.log(response);
});
  promise.catch((err) => {
   
    console.log(err);
  });