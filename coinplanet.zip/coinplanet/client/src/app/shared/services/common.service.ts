import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, observable } from 'rxjs';
import { stringify } from '@angular/compiler/src/util';


@Injectable({providedIn: 'root'})
export class CommonService {
  baseurl = '/coinplanet/api/staticdata/';
  constructor(private httpClient: HttpClient) { }
  getStaticData(type: string): Observable<any> {
    let url: any;
    if (type === 'resources') {
    url = this.baseurl + 'res';
    }
    console.log(url);
   return this.httpClient.get<object>(url);
  }
}



