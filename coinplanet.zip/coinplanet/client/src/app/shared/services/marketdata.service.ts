import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class MarketdataService {
  newsItems: object[];
  newsUrl = 'api/md/price/latest';
  constructor(private http: HttpClient) { }
  getMarketData(): Observable<any[]> {
           return this.http.get<object[]>(this.newsUrl);
  }
}
