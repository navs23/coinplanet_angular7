import { TestBed } from '@angular/core/testing';

import { FiatdataService } from './fiatdata.service';

describe('FiatdataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FiatdataService = TestBed.get(FiatdataService);
    expect(service).toBeTruthy();
  });
});
