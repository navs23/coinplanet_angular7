import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../../shared/services/common.service';

@Component({
  selector: 'app-resources',
  templateUrl: './resources.component.html',
  styleUrls: ['./resources.component.css']
})
export class ResourcesComponent implements OnInit {
  resources = [];
  keys = [];
  constructor(private commonSrv: CommonService) { }

  ngOnInit() {
      this.commonSrv.getStaticData('resources').subscribe((res) => {
      this.resources = res;
      this.keys = Object.keys(res);
      console.log(this.keys);
    });
  }

}
