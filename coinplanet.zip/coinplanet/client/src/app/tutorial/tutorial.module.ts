import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ResourcesComponent } from './components/resources/resources.component';
import { StartComponent } from './components/start/start.component';
import { GlossaryComponent } from './components/glossary/glossary.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [ResourcesComponent, StartComponent, GlossaryComponent]
})
export class TutorialModule { }
