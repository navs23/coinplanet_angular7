import { Injectable } from '@angular/core';
import { HttpRequest, HttpResponse, HttpHandler, HttpEvent, HttpInterceptor, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { delay, mergeMap, materialize, dematerialize } from 'rxjs/operators';
import { FakeTweets } from './tweets';

@Injectable()
export class FakeBackendInterceptor implements HttpInterceptor {
 
    constructor(private fakeTweets: FakeTweets) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        console.log(request.url);
        // wrap in delayed observable to simulate server api call
        return of(null).pipe(mergeMap(() => {
            // get users
            if (request.url.endsWith('api/news') && request.method === 'GET') {
                console.log('fake tweets')
                return of(new HttpResponse({ status: 200, body: this.fakeTweets.getTweets() }));
            // check for fake auth token in header and return users if valid, this security is implemented server side in a real application
                if (request.headers.get('Authorization') === 'Bearer fake-jwt-token') {
                    return of(new HttpResponse({ status: 200, body: this.fakeTweets.getTweets() }));
                } else {
                    // return 401 not authorised if token is null or invalid
                    return throwError({ status: 401, error: { message: 'Unauthorised' } });
                }
            }


            // register user
            if (request.url.endsWith('/users/register') && request.method === 'POST') {
                if (false) {
                    return throwError({ error: { message: 'Username is already taken' } });
                }
                // respond 200 OK
                return of(new HttpResponse({ status: 200 }));
            }

            // pass through any requests not handled above
            return next.handle(request);
        }))
// call materialize and dematerialize to ensure delay even if an error is thrown (https://github.com/Reactive-Extensions/RxJS/issues/648)
        .pipe(materialize())
        .pipe(delay(500))
        .pipe(dematerialize());
    }
}

export let fakeBackendProvider = {
    // use fake backend in place of Http service for backend-less development
    provide: HTTP_INTERCEPTORS,
    useClass: FakeBackendInterceptor,
    multi: true
};