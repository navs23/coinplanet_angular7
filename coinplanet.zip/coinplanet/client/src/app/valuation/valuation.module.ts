import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ValuationComponent } from './components/valuation/valuation.component';
import { TnxExplorerComponent } from './components/tnx-explorer/tnx-explorer.component';


@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [ValuationComponent, TnxExplorerComponent]
})
export class ValuationModule { }
