import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-tnx-explorer',
  templateUrl: './tnx-explorer.component.html',
  styleUrls: ['./tnx-explorer.component.css']
})
export class TnxExplorerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  onClick(event) {
    let address: string;
    address = event.target.value;
    console.log('%s', event.target.value );
    // const promise = blockexpolorer.balance(address);

    // promise.then(balance => {
    //   console.log(balance);
    // });
  }

}
