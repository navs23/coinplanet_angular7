import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-valuation',
  templateUrl: './valuation.component.html',
  styleUrls: ['./valuation.component.css']
})
export class ValuationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
