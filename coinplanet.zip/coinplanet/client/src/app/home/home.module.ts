import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './components/home/home.component';
import { NewsComponent } from './components/news/news.component';
import { CalcComponent } from './components/calc/calc.component';
import { CoinplanetMaterialModule } from '../coinplanet-material.module';

@NgModule({
  imports: [
    CommonModule,
    CoinplanetMaterialModule
  ],
  declarations: [ HomeComponent, NewsComponent, CalcComponent]
})
export class HomeModule { }
