import { Component, OnInit } from '@angular/core';
import { NewsService } from '../../../shared/services/news.service';
import { Observable } from 'rxjs';

import { CoinplanetMaterialModule } from '../../../coinplanet-material.module';

@Component({
  selector: 'app-cryptonews',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})

export class NewsComponent implements OnInit {
  tweets: any;
  constructor(private newsService: NewsService) { }
  ngOnInit() {
  this.newsService.getNews().subscribe((res) => {
    console.log(res);
    this.tweets = res;
  });
  }

}
