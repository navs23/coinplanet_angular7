import { Component, OnInit } from '@angular/core';
import { MarketdataService } from '../../../shared/services/marketdata.service';
import { CoinplanetMaterialModule } from '../../../coinplanet-material.module';
import { Observable } from 'rxjs';
import * as _ from 'lodash';
import * as $ from 'jquery';
import { FiatdataService } from 'src/app/shared/services/fiatdata.service';
import { R3_COMPILE_INJECTABLE__POST_NGCC__ } from '@angular/core/src/ivy_switch/compiler';
import { QueryValueType } from '@angular/core/src/view';
import { analyzeAndValidateNgModules } from '@angular/compiler';
@Component({
  selector: 'app-calc',
  templateUrl: './calc.component.html',
  styleUrls: ['./calc.component.css']
})
export class CalcComponent implements OnInit {
  marketData: object;
  rates: object[];
  constructor(private marketDataService: MarketdataService, private fiatSerivce: FiatdataService) { }

  ngOnInit() {
    this.marketDataService.getMarketData().subscribe((res) => {
      this.marketData = res;
    });

    this.fiatSerivce.getRates()
    .subscribe((rates) => {
      this.rates = Object.keys(rates).map(key => ({ key, value: rates[key] }));
      // console.log(this.rates);
    });
  }
  onChange($event) {
    this.recalcGrid($event);
  }
recalcGrid(event) {

  let qty = 0.00;
  qty = event.target.value;
  let totalValue = 0.00;
  totalValue = event.target.attributes.rate.value * qty;
  // console.log('qty = %s, totalvalue=%s', qty, totalValue );

  $('input[name = "calc-item"]').not(this).each((i, e) => {
    $(e).val(totalValue / $(e).attr('rate'));
    // console.log('symbol=%s,rate=%s', $(e).attr('symbol')  , $(e).attr('rate') );

  });

}
}
