import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/components/home/home.component';
import { ValuationComponent } from './valuation/components/valuation/valuation.component';
import { TradeComponent } from './trade/components/trade/trade.component';
import { ChatComponent } from './chat/components/chat/chat.component';
import { StartComponent } from './tutorial/components/start/start.component';
import { ResourcesComponent } from './tutorial/components/resources/resources.component';
import { GlossaryComponent } from './tutorial/components/glossary/glossary.component';



const routes: Routes = [
  {path : '' , component : HomeComponent },
  {path : 'home' , component : HomeComponent },
  {path : 'valuation' , component : ValuationComponent },
  {path : 'trade' , component : TradeComponent },
  {path : 'chat' , component : ChatComponent },
  {path : 'getstarted' , component : StartComponent },
  {path : 'resources' , component : ResourcesComponent },
  {path : 'glossary' , component : GlossaryComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
