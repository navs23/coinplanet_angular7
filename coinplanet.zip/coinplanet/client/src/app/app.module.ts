import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeModule } from './home/home.module';
import { ValuationModule } from './valuation/valuation.module';
import { TradeModule } from './trade/trade.module';
import { ChatModule } from './chat/chat.module';
import { TutorialModule } from './tutorial/tutorial.module';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FakeTweets } from './helpers/tweets';
import { fakeBackendProvider } from './helpers/fake-backend';



@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HomeModule,
    ValuationModule,
    TradeModule,
    ChatModule,
    TutorialModule,
    HttpClientModule,
    BrowserAnimationsModule

  ],
  providers: [fakeBackendProvider, FakeTweets],
  bootstrap: [AppComponent ]
})
export class AppModule { }
