const express = require('express');

var router = express.Router();
var newsService = require("../services/news/service");
var MdFactory = new require('../services/marketData/factory');
var RatesFactory = new require('../services/fiat/factory');
const staticData = require('../services/data/static-data.js');

var blockexplorer = require('blockchain.info/blockexplorer');

var mdfactory = new MdFactory('cmc');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.sendfile('./public/dist/index.html'); 
 
});

router.get('/coinplanet/api/news', function(req, res, next) {
 
 var promise=newsService.getTopNews();
 promise.then((articles)=>{res.send(articles)});
 promise.catch((error)=>{res.send(error)});
});

router.get('/coinplanet/api/md/price/latest', function(req, res, next) {

  var marketDataService = mdfactory.getMarketDataServiceByProider();

var promise = marketDataService.getPrice(true);

promise.then(response => {
  res.send(response.data);
   // console.log(response);
  });
  promise.catch((err) => {
    res.send(err);
    console.log(err);
  });

});

//
router.get('/coinplanet/api/rates', function(req, res, next) {
var fixer = new RatesFactory('fixer');
var ds = fixer.getFiatService();
var promise = ds.getRates(true);

promise.then(response => {
  res.send(response.rates);
    //console.log(response);
  });
  promise.catch((err) => {
    res.send(err);
    //console.log(err);
  });

  });

//
router.get('/coinplanet/api/getrates', function(req, res, next) {
  var fixer = new RatesFactory('fixer');
  var ds = fixer.getFiatService();
  var promise = ds.getRates(true);
  
  promise.then(response => {
    res.send(response.rates);
      //console.log(response);
    });
    promise.catch((err) => {
      res.send(err);
      //console.log(err);
    });
  
    });
  //https://fixer.io/product + 132321

// blockexplorer

router.get('/coinplanet/api/be/balance/:address',(req,res,next) =>{
  let address = req.params.address;
  const balance = blockexplorer.getBalance(address);
  res.send(balance);
});
// resources route
router.get('/coinplanet/api/staticdata/:type',(req,res,next) =>{
  
  res.send(staticData.getStaticData(req.params.type || ''))
  
});

var restify = require('restify');

function respond(req, res, next) {
  res.send('hello ' + req.params.name);
  next();
}

var restify = require('restify');

function respond(req, res, next) {
  res.send('hello ' + req.params.name);
  next();
}


module.exports = router;
