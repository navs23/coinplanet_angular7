var assert = require('assert');
var newService=require('../services/news');

describe('news service test',()=>{
    it('should return news items',()=>{
        var newsPromise=newService.getNews();

        newsPromise.then((ni)=>{
          
           assert.equal(20,ni.length);
        });

        newsPromise.catch((err)=>{
            assert.isOk(false,'news service failed to return news items.');
        });
        
    });
   
});
