(function(socket){
    var online=0;
    var crptoStats = {
        btc_total_mktcap:"$10b",
        btc_24H_vol:"$5b"
    };
    socket.start = (server)=>{
    var io = require('socket.io')(server);
        setInterval(()=>{

            io.emit('crypto-data',crptoStats) ;
            
        },1000* 2);
        
        io.on("connection",(socket)=>{

            io.emit('connected',(++online));  
            
            socket.on('disconnect', function () {
            
                io.emit('disconnected',--online);
                
          
            });

        });

        
    }
}(module.exports));
